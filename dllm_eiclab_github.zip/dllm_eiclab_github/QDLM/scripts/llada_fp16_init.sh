export HF_DATASETS_TRUST_REMOTE_CODE=true
export HF_ALLOW_CODE_EVAL=1

lm_eval --model llada_dist \
    --model_args model_path='/model/lushaoqiang/dLLM-EIC/LLaDA-8B-Instruct' \
    --tasks piqa \
    --batch_size 8 \

export HF_DATASETS_TRUST_REMOTE_CODE=true
export HF_ALLOW_CODE_EVAL=1

export PYTHONWARNINGS="ignore"
#conda activate qdlm
#export HF_ENDPOINT=https://hf-mirror.com
#huggingface-cli login
#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
#huggingface-cli whoami



DIRPATH="$(cd -P -- "$(dirname -- "${BASH_SOURCE[0]}")/.." >/dev/null 2>&1 && pwd)"
MODEL_PATH='/model/lushaoqiang/dLLM-EIC/LLaDA-8B-Instruct' 
W_BIT=8
A_BIT=8

# model_path: the path to the pretrained model
# block_size: the block size for DuQuant rotation
# max_rotation_step: the greedy rotation step for DuQuant quantization
# --swc: the ratio of weight clipping
# --lac: the ratio of activation clipping
# we use asymmetric per-channel quantization for weights and per-tensor quantization for activations in DuQuant

python $DIRPATH/DuQuant/generate_act_scale_shift.py --model $MODEL_PATH

# general tasks
# --tasks hellaswag,piqa,winogrande,arc_easy,arc_challenge
EN_general=0
if [ "$EN_general" -eq 1 ]; then
python $DIRPATH/DuQuant/main.py \
    --block_size 128 \
    --max_rotation_step 256 \
    --epochs 0 \
    --wbits $W_BIT \
    --abits $A_BIT \
    --model $MODEL_PATH \
    --quant_method duquant \
    --alpha 0.5 \
    --smooth \
    --lac 0.9 \
    --swc 0.8 \
    --task piqa 
fi

# MMLU
EN_MMLU=0
if [ "$EN_MMLU" -eq 1 ]; then
python $DIRPATH/DuQuant/main.py \
    --block_size 128 \
    --max_rotation_step 256 \
    --epochs 0 \
    --wbits $W_BIT \
    --abits $A_BIT \
    --model $MODEL_PATH \
    --quant_method duquant \
    --alpha 0.5 \
    --smooth \
    --lac 0.9 \
    --swc 0.8 \
    --task mmlu \
    --num_fewshot 5 \
    --mc_num 1 
fi

#=====================================
# GSM8K
#=====================================
# ========================= 说明（集中注释） =========================
# 量化/评测设置（DuQuant + W8A8）：
# --block_size 128        ：权重量化按“组”做 per-channel（group-wise），每组通道数=128（常用默认）。
# --max_rotation_step 256 ：DuQuant 在校准时求旋转矩阵的最大迭代步数/预算（更大=更充分，稍慢）。
# --epochs 0              ：纯后训练量化（PTQ），不做梯度更新，不训练，只做校准与推理。
# --wbits / --abits       ：W8A8 的位宽；wbits=8（权重8bit），abits=8（激活8bit）。
# --model                 ：本地模型路径（LLaDA-8B-Instruct 的权重目录）。
# --quant_method duquant  ：选用 DuQuant（旋转类 W8A8）方法。
# --alpha 0.5             ：DuQuant 的旋转/缩放平衡系数（0~1 之间，0.5 为经验值）。
# --smooth                ：启用 SmoothQuant 风格的预平衡（抑制极值，稳量化范围）。
# --lac 0.9               ：Layer-wise Activation Clipping 强度（如按 90% 分位裁剪激活 outlier）。
# --swc 0.8               ：Smoothing Weight Coefficient（平滑强度系数，配合 --smooth 使用）。
#
# 评测任务与解码相关：
# --task gsm8k            ：评测基准选 GSM8K（数学推理）。
# --num_fewshot 4         ：Few-shot 提示数 = 4（每题前拼 4 个示例问答；不是训练）。
# --gen_length 256        ：最大新生成 token 数（等价于 lm_eval 的 max_gen_toks）。
# --steps 256             ：扩散式解码的“扩散步数”（dLLM 推理超参；步数越大推理更稳但更慢）。
# --block_length 32       ：扩散块长度/每步内的子长度（配合 --steps 的分块步长；与速度/稳定性权衡相关）。
# ===================================================================

#export CUDA_VISIBLE_DEVICES=0,1

EN_GSM8K=1
if [ "$EN_GSM8K" -eq 1 ]; then
python $DIRPATH/DuQuant/main.py \
    --block_size 128 \
    --max_rotation_step 256 \
    --epochs 0 \
    --wbits $W_BIT \
    --abits $A_BIT \
    --model $MODEL_PATH \
    --quant_method duquant \
    --alpha 0.5 \
    --smooth \
    --lac 0.9 \
    --swc 0.8 \
    --task gsm8k \
    --gen_length 256 \
    --steps 256 \
    --block_length 32 \
    --num_fewshot 4 \
    --limit 20 
fi



#export CUDA_VISIBLE_DEVICES=0,1,2,3
#unset CUDA_VISIBLE_DEVICES
#  --num-gpus-per-model 4 \
#  --num-gpus-total 4 \
#  --max-gpu-memory 22GiB
#    --multigpu


# MATH
EN_MATH=0
if [ "$EN_MATH" -eq 1 ]; then
python $DIRPATH/DuQuant/main.py \
    --block_size 128 \
    --max_rotation_step 256 \
    --epochs 0 \
    --wbits $W_BIT \
    --abits $A_BIT \
    --model $MODEL_PATH \
    --quant_method duquant \
    --alpha 0.5 \
    --smooth \
    --lac 0.9 \
    --swc 0.8 \
    --tasks minerva_math  --num_fewshot 0 --gen_length 256 --steps 256 --block_length 64 
fi

# HumanEval
EN_HumanEval=0
if [ "$EN_HumanEval" -eq 1 ]; then
python $DIRPATH/DuQuant/main.py \
    --block_size 128 \
    --max_rotation_step 256 \
    --epochs 0 \
    --wbits $W_BIT \
    --abits $A_BIT \
    --model $MODEL_PATH \
    --quant_method duquant \
    --alpha 0.5 \
    --smooth \
    --lac 0.9 \
    --swc 0.8 \
    --task humaneval --gen_length 512 --steps 512 --block_length 32 --num_fewshot 0 
fi

# MBPP
EN_MBPP=0
if [ "$EN_MBPP" -eq 1 ]; then
python $DIRPATH/DuQuant/main.py \
    --block_size 128 \
    --max_rotation_step 256 \
    --epochs 0 \
    --wbits $W_BIT \
    --abits $A_BIT \
    --model $MODEL_PATH \
    --quant_method duquant \
    --alpha 0.5 \
    --smooth \
    --lac 0.9 \
    --swc 0.8 \
    --task mbpp --gen_length 512 --steps 512 --block_length 32 --num_fewshot 3 
fi
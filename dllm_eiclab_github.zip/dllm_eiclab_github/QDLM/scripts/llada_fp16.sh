export HF_DATASETS_TRUST_REMOTE_CODE=true
export HF_ALLOW_CODE_EVAL=1
export PYTHONWARNINGS="ignore"
#conda activate qdlm

#export HF_HOME=/model/cache/hf
#export HF_DATASETS_CACHE=/model/cache/hf/datasets
#export TRANSFORMERS_CACHE=/model/cache/hf/hub

#export HF_ENDPOINT=https://hf-mirror.com
#huggingface-cli login
#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
#huggingface-cli whoami

#/opt/conda/envs/qdlm/bin/python /model/lushaoqiang/dLLM-EIC/main/gsm.py

lm_eval --model llada_dist \
    --model_args model_path='/model/lushaoqiang/dLLM-EIC/LLaDA-8B-Instruct' \
    --tasks gsm8k \
    --batch_size 1 \
    --limit 10 \

import setuptools


# This is to make sure that the package supports editable installs
setuptools.setup()
